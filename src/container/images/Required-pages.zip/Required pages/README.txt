README

FOLDERS
	Current Bootstrap theme - css+html
		- This folder contains the bootstrap theme that the website is currently using
		- included are all the css/js
		- a few pages for design consideration

	mDash - Current html pages
		- This contains the chameleon .pt templates of the current pages that need design
		- can open .pt files with an html editor, they are in html format
		- _layout.pt contains the header and footer, other pages contain the main content

	Page designs - open start
		- open start.html to check out the page designs of the 6 pages requested
		- text in red indicates notes I've made to help you understand what is wanted or added notes
		- created in Axure, if there is a placeholder (box with a diagonal lines), then want design from you

DELIVERABLES:
	- html / css / js / graphics for each page
	- Please NOTE where you have added to the css or create a separate css file